Algoritmo OrdenarTresNumeros
    Definir num1, num2, num3, temp Como Entero
	escribir "bievenidos a el orden de tres numeros de manor a mayor"
    Escribir "por favor ingrese el primer n�mero: "
    Leer num1
    Escribir "por favor ingrese el segundo n�mero: "
    Leer num2
    Escribir "por favor ingrese el tercer n�mero: "
    Leer num3
	
    Si num1 > num2 Entonces
        temp <- num1
        num1 <- num2
        num2 <- temp
    FinSi
	
    Si num2 > num3 Entonces
        temp <- num2
        num2 <- num3
        num3 <- temp
    FinSi
	
    Si num1 > num2 Entonces
        temp <- num1
        num1 <- num2
        num2 <- temp
    FinSi
	
    Escribir "Los n�meros en orden ascendente son: ", num1, ", ", num2, ", ", num3
FinAlgoritmo
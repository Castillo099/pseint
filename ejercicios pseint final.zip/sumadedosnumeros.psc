Algoritmo sumadedosnumeros
	definir num1, num2, resultadosuma Como Entero
	// elaborado por ANDRES FELIPE TRUJILLO
        // 1 SEMESTRE JORNADA NOCTURNA
	escribir "bienvenido a la suma de dos numeros"
	escribir "por favor ingrese el primer numero "
	leer num1
	escribir "por favor ingrese el segundo numero"
	leer num2 
	// aqui se realiza la operacion de la suma
	resultadosuma <- num1 + num2
	escribir "el resultado de la suma de dos numeros es: ", resultadosuma
FinAlgoritmo

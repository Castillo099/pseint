Algoritmo ConversionDolarpesoscol
    Definir dolares, pesoscol, tasaCambio Como Real
	escribir "bienvenido"
    Escribir "Ingrese el monto en d�lares: "
    Leer dolares
	
    Escribir "Ingrese la tasa de cambio (d�lares por pesos col): "
    Leer tasaCambio

    pesoscol <- dolares * tasaCambio

    Escribir dolares, " d�lares equivalen a ", pesoscol, " pesoscol."
FinAlgoritmo
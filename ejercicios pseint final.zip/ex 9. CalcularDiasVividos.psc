Algoritmo CalcularDiasVividos
    Definir diaNacimiento, mesNacimiento, anioNacimiento, diaActual, mesActual, anioActual, diasVividos Como Entero
	
	Escribir "bienvenidos a calcular el dia vividos"
    Escribir "por favor ingrese el d�a de nacimiento: "
    Leer diaNacimiento
    Escribir "por favor ingrese el mes de nacimiento (n�mero): "
    Leer mesNacimiento
    Escribir "por favor ingrese el a�o de nacimiento: "
    Leer anioNacimiento
	
    Escribir "por favor ingrese el d�a actual: "
    Leer diaActual
    Escribir "por favor ingrese el mes actual (n�mero): "
    Leer mesActual
    Escribir "por favor ingrese el a�o actual: "
    Leer anioActual
	
    diasVividos <- (anioActual - anioNacimiento - 1) * 365 
    diasVividos <- diasVividos + (mesActual - mesNacimiento) * 30  
    diasVividos <- diasVividos + (diaActual - diaNacimiento) 
	
    Escribir "Has vivido aproximadamente ", diasVividos, " d�as."
	
FinAlgoritmo
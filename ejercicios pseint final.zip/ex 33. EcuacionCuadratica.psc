Algoritmo EcuacionCuadratica
    Definir a, b, c, discriminante, x1, x2 Como Real
    Definir raizCuadrada Como Real
	
	Escribir "bienvenidos a la ecuacion cuadratica"
    Escribir "por favor ingrese el valor de a: "
    Leer a
    Escribir "por favor ingrese el valor de b: "
    Leer b
    Escribir "por favor ingrese el valor de c: "
    Leer c
	
    discriminante <- b^2 - 4 * a * c
	
    Si discriminante >= 0 Entonces
        raizCuadrada <- Raiz(discriminante)
		
        x1 <- (-b + raizCuadrada) / (2 * a)
        x2 <- (-b - raizCuadrada) / (2 * a)
		
        Escribir "Las soluciones de la ecuaci�n son:"
        Escribir "x1 = ", x1
        Escribir "x2 = ", x2
    SiNo
        Escribir "La ecuaci�n no tiene soluciones reales."
    FinSi
	
FinAlgoritmo
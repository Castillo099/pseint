algoritmo ClasificarEdades
    Definir contadorNi�os, contadorAdolescentes, contadorAdultos, contadorAncianos, i, cantidadEdades, edad Como Entero
	
    contadorNi�os <- 0
    contadorAdolescentes <- 0
    contadorAdultos <- 0
    contadorAncianos <- 0

    Escribir "Ingrese la cantidad de edades a clasificar: "
    Leer cantidadEdades

    Para i Desde 1 Hasta cantidadEdades Hacer
        Escribir "Ingrese la edad ", i, ": "
        Leer edad
        Si edad >= 0 Y edad <= 12 Entonces
            contadorNi�os <- contadorNi�os + 1
        Sino Si edad >= 13 Y edad <= 17 Entonces
				contadorAdolescentes <- contadorAdolescentes + 1
			Sino Si edad >= 18 Y edad <= 64 Entonces
					contadorAdultos <- contadorAdultos + 1
				Sino Si edad >= 65 Entonces
						contadorAncianos <- contadorAncianos + 1
					Sino
						Escribir "Edad inv�lida. Por favor ingrese una edad no negativa."
					Fin Si
				FinSi
			FinSi
		FinSi
		
	Fin Para

	Escribir "Cantidad de ni�os (0-12 a�os): ", contadorNi�os
	Escribir "Cantidad de adolescentes (13-17 a�os): ", contadorAdolescentes
	Escribir "Cantidad de adultos (18-64 a�os): ", contadorAdultos
	Escribir "Cantidad de ancianos (65 a�os y m�s): ", contadorAncianos
FinAlgoritmo


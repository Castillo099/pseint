Algoritmo calcularnumerosprimos
	Definir a, b, c, x, aux Como Entero
	
escribir "bievenido al calculo de numeros primos"
Escribir "Ingresa 2 numeros"
leer a,b
	
si a == b Entonces
		Escribir "Ingresa 2 numeros diferentes"
	SiNo
		si a > b Entonces
			aux = a
			a = b
			b = aux
		FinSi
		Mientras a <= b Hacer
		x = 1
		c = 0
		Mientras x <= a Hacer
			si a mod x == 0 Entonces
				c = c + 1
			FinSi
			x = x + 1 
		FinMientras
		si c == 2 Entonces
			escribir a
		FinSi
		a = a + 1
	FinMientras
FinSi

finalgoritmo

Algoritmo horasasegundos
	definir min, hora, segu Como Entero
	
	escribir "bienvenido a el comvertidor de horas  a segundos"
	escribir "por favor ingrese la cantidad de horas"
	leer hora
	Escribir "por favor ingrese la cantidad de minutos"
	leer min
	escribir "por favor ingrese la cantidad de segundos"
	leer segu
	
	total <- hora * 3600 + min * 60 + segu
	Escribir "el total de segundos es ", total
FinAlgoritmo


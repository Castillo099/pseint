Algoritmo CalcularHipotenusa
    Definir catetoA, catetoB, hipotenusa Como Real
	escribir "bienvenidos a  el calculo de la hipotenusa "
    Escribir "por favor ingrese la longitud del cateto adyacente: "
    Leer catetoA
    Escribir "Ingrese la longitud del cateto opuesto: "
    Leer catetoB
	
    hipotenusa = raiz(catetoA^2 + catetoB^2)
	
	
    Escribir "La longitud de la hipotenusa es: ", hipotenusa
	
FinAlgoritmo
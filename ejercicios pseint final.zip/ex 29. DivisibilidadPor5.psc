Algoritmo DivisibilidadPor5
    Definir num Como Entero
	
	Escribir "bienvenido a verificacion de el numero 5"
    Escribir "por favor ingrese un n�mero: "
    Leer num
	
    Si num MOD 5 = 0 Entonces
        Escribir num, " es divisible entre 5."
    SiNo
        Escribir num, " no es divisible entre 5."
    FinSi
	
FinAlgoritmo
Proceso ImprimirNumerosPrimos
    Definir cantidadPrimos,contador Como Entero
    Definir esPrimo Como Logico
	escribir "bienvenidos a el resultado de numeros primos"
    Escribir "por favor ingrese la cantidad de n�meros primos a imprimir: "
    Leer cantidadPrimos
	
    contador <- 0
    numero <- 2  
	
    Mientras contador < cantidadPrimos Hacer
        esPrimo <- Verdadero  
		
        Para i Desde 2 Hasta Raiz(numero) Hacer
            Si numero Mod i = 0 Entonces
                esPrimo <- Falso
            Fin Si
        Fin Para
		
        Si esPrimo Entonces
            Escribir numero
            contador <- contador + 1  
        Fin Si
		
        numero <- numero + 1  
    Fin Mientras
Fin Proceso

Algoritmo InvertirunNumero
    Definir num, inverso, digito Como Entero
    Escribir "bienvenido al inverso de un numero" 
    Escribir "por favor ingrese un n�mero: "
    Leer num
    inverso <- 0
	
    Mientras num <> 0 Hacer
        digito <- num MOD 10
        inverso <- inverso * 10 + digito
        num <- trunc(num / 10)
    FinMientras
	Escribir "El n�mero invertido es: ", inverso

FinAlgoritmo
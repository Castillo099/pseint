Algoritmo InteresCompuestoanual
    Definir capitalInicial, tasaInteres, numAnios, montoFinal Como Real
    Escribir "bienvenido a la consulta de sus interes"
    Escribir "por favor ingrese el capital inicial: "
    Leer capitalInicial
    Escribir "por favor ingrese la tasa de inter�s anual (en porcentaje): "
    Leer tasaInteres
    Escribir "por favor ingrese el n�mero de a�os: "
    Leer numAnios
	
    tasaInteres <- tasaInteres / 100
	
    montoFinal <- capitalInicial * (1 + tasaInteres) ^ numAnios

    Escribir "El monto final despu�s de ", numAnios, " a�os es: ", montoFinal
	
FinAlgoritmo

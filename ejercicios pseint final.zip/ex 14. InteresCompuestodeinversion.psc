Algoritmo InteresCompuestodeinversion
    Definir capitalInicial, tasaInteres, tiempo, montoFinal Como Real
	
	escribir "bienvenido a el interes compuesto de su inversion"
    Escribir "por favor ingrese el capital inicial: "
    Leer capitalInicial
    Escribir "por favor ingrese la tasa de inter�s anual (en porcentaje): "
    Leer tasaInteres
    Escribir "por favor ingrese el tiempo en a�os: "
    Leer tiempo

    tasaInteres <- tasaInteres / 100

    montoFinal <- capitalInicial * (1 + tasaInteres) ^ tiempo

    Escribir "El monto final de la inversi�n es: ", montoFinal
	
FinAlgoritmo
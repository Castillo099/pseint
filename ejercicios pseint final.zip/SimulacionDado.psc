Algoritmo SimulacionDado
    Definir numLanzamientos, dado, contador1, contador2, contador3, contador4, contador5, contador6 Como Entero
	Escribir "bienvenido a la simulacion de un dado"
    Escribir "Ingrese el n�mero de lanzamientos del dado: "
    Leer numLanzamientos
	
    contador1 <- 0
    contador2 <- 0
    contador3 <- 0
    contador4 <- 0
    contador5 <- 0
    contador6 <- 0

    Para i <- 1 Hasta numLanzamientos Hacer
        dado <- Aleatorio(1, 6)
        Seg�n dado Hacer
	       Caso 1: contador1 <- contador1 + 1
	       Caso 2: contador2 <- contador2 + 1
	       Caso 3: contador3 <- contador3 + 1
	       Caso 4: contador4 <- contador4 + 1
	       Caso 5: contador5 <- contador5 + 1
	       Caso 6: contador6 <- contador6 + 1
      FinSeg�n
   FinPara

Escribir "Resultados de los lanzamientos:"
Escribir "N�mero 1: ", contador1, " veces"
Escribir "N�mero 2: ", contador2, " veces"
Escribir "N�mero 3: ", contador3, " veces"
Escribir "N�mero 4: ", contador4, " veces"
Escribir "N�mero 5: ", contador5, " veces"
Escribir "N�mero 6: ", contador6, " veces"

FinAlgoritmo
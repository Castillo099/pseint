Algoritmo SumaPares
    Definir num, suma, i Como Entero
    Escribir "bienvenido a la suma de numeros pares"
    Escribir "por favor ingrese un n�mero: "
    Leer num

    suma <- 0
	
    Para i <- 2 Hasta num Hacer
        Si i MOD 2 = 0 Entonces
            suma <- suma + i
        FinSi
    FinPara
    Escribir "La suma de los n�meros pares hasta ", num, " es: ", suma
	
FinAlgoritmo
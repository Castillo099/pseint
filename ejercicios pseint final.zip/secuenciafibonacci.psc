Algoritmo secuenciafibonacci
	definir num Como Entero
	Escribir "bienvenido a la secuencia de fibonacci"
	Escribir "Por favor ingrese numero: "
	leer num
	
	a<-0
	b<-1
	
	Para i<-1 Hasta num Hacer
		Escribir a
		c<-a+b
		a<-b
		b<-c
	FinPara
FinAlgoritmo

Algoritmo AlquilerAutos
    Definir tipoAuto, duracion como entero
	definir costoPorDia, costoTotal Como Real
	
	Escribir "bievenidos a el calculo de alquiler de autos por dia"
    Escribir "Tipos de autos disponibles:"
    Escribir "1. antiguo"
    Escribir "2. moderno"
    Escribir "3. clasico"
    Escribir "4. Lujo"
	
    Escribir "por favor ingrese el n�mero correspondiente al tipo de auto que desea alquilar: "
    Leer tipoAuto
	
    Escribir "por favor ingrese la duraci�n del alquiler en d�as: "
    Leer duracion
	
   
Seg�n tipoAuto Hacer
		1: costoPorDia <- 5000
		2: costoPorDia <- 7000
		3: costoPorDia <- 10000
		4: costoPorDia <- 15000
	De Otro Modo:
	Escribir "Opci�n inv�lida."
FinSeg�n

costoTotal <- costoPorDia * duracion

Escribir "El costo total del alquiler es: $", costoTotal

FinAlgoritmo
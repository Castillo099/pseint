Algoritmo NumerosMayoresQueLaMedia
    Definir N, i, contadorMayorQueMedia Como Entero
    Definir suma, media, lista Como Real
	escribir "bienvenidos a los numeros mayores de la arismetica"
    Escribir "por favor ingresa la cantidad de n�meros: "
    Leer N
	
    suma = 0
	
    Dimension lista[N]
    Para i = 1 Hasta N Con Paso 1 Hacer
        Escribir "por favor ingresa el n�mero ", i, ":"
        Leer lista[i]
        suma = suma + lista[i] 
    FinPara
	
    media = suma / N
    contador = 0
	
    Para i = 1 Hasta N Con Paso 1 Hacer
        Si lista[i] > media Entonces
            contador = contador + 1
        FinSi
    FinPara

    Escribir "La media aritm�tica es: ", media
    Escribir "Cantidad de n�meros mayores que la media: ", contador
FinAlgoritmo

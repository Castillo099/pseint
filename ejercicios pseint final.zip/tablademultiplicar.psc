Algoritmo tablademultiplicar
	Definir numero Como Entero
	escribir "bienvenidos al resultado de la tabla de un numero"
    Escribir "Ingrese un n�mero para calcular su tabla de multiplicar:"
    Leer numero
	
    Escribir "Tabla de multiplicar de ", numero, ":"
    
    Para i = 1 Hasta 10 Hacer
        Escribir numero, " x ", i, " = ", numero * i
    FinPara
FinAlgoritmo

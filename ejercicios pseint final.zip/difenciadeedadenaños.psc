Algoritmo difenciadeedadena�os
	Definir a�oNacimiento1, a�oNacimiento2, diferenciaEdad Como Entero
	
	Escribir "bienvenido a la consulta de diferencia de edad"
    Escribir "por favor ingrese su a;o de nacimiento"
	leer a�oNacimiento1 
	Escribir "por favor ingrese otra fecha de nacimiento "
	leer a�oNacimiento2
    
    diferenciaEdad <- (a�oNacimiento1 - a�oNacimiento2)
    
    Escribir "La diferencia de edad entre ambas personas es:", diferenciaEdad, "a�os."
FinAlgoritmo

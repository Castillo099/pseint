Algoritmo Cuadradodeasteriscos
    Definir Num, fila, columna Como Entero
	Escribir "bieinvenidos a el cuadro de asteriscos"
    Escribir "por favor ingrese el tama�o del lado del cuadrado: "
    Leer Num
	
    Mientras Num <= 0 Hacer
        Escribir "El tama�o debe ser un n�mero positivo. Intente nuevamente:"
        Leer Num
    FinMientras
	
    Para fila <- 1 Hasta Num Hacer
        Para columna <- 1 Hasta Num Hacer
            Escribir Sin Saltar "*"
        FinPara
        Escribir ""  
    FinPara
	
FinAlgoritmo
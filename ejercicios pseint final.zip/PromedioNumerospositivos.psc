Algoritmo PromedioNumerospositivos
	Definir num, suma, contador Como Entero
	Escribir "bienvenido al promedio de un numero"
	
	suma <- 0
	contador <- 0
	
	Escribir "por favor ingrese los n�meros y Para finalizar, ingrese un n�mero negativo."
	
	Repetir
	   Leer num
		Si num >= 0 Entonces
		     suma <- suma + num
		   contador <- contador + 1
		FinSi
		Hasta Que num < 0
		
		Si contador > 0 Entonces
			Escribir "El promedio de los n�meros ingresados es: ", suma / contador
		SiNo
			Escribir "No se ingresaron n�meros positivos."
		FinSi
FinAlgoritmo


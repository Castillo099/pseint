Algoritmo determinarnumeropositivoynegativo
	definir numero Como Entero
	escribir "bienvenidos a la consulta de un numero positivo o negativo"
	Escribir "por favor ingrese un n�mero: "
	Leer numero
	Si numero < 0 Entonces
		Escribir "el numero es Negativo"
	SiNo
		si numero > 0 Entonces
			escribir "el numero es positivo"
		sino 
		Escribir "el numero es cero"
		fin si
	Fin Si
FinAlgoritmo

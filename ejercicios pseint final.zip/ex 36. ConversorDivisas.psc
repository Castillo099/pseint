Algoritmo ConversorDivisas
	
    Definir montoLocal, tasaCambio, montoConvertido Como Real
    Definir monedaLocal, monedaDestino Como Cadena
	
	escribir "bienvenidos a ewl convertidor de  divisas"
    Escribir "Ingrese el monto en su moneda local: "
    Leer montoLocal
    Escribir "Ingrese el s�mbolo de su moneda local: "
    Leer monedaLocal
    Escribir "Ingrese el s�mbolo de la moneda a la que desea convertir: "
    Leer monedaDestino
    Escribir "Ingrese la tasa de cambio (1 ", monedaLocal, " = ): "
    Leer tasaCambio
	
    // Calcular el monto convertido
    montoConvertido <- montoLocal * tasaCambio
	
    // Mostrar el resultado
    Escribir montoLocal, monedaLocal, " equivalen a ", montoConvertido, monedaDestino
	
FinAlgoritmo
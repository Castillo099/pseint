Algoritmo sistemadeventas
	Definir cantidadProductos, i, cantidades Como Entero
    Definir producto, nombres Como Caracter
    Definir precio, totalCompra Como Real
    
    Escribir "�Cu�ntos productos desea ingresar? "
    Leer cantidadProductos
	
    Para i = 1 Hasta cantidadProductos Hacer
        Escribir "Ingrese el nombre del producto ", i, ": "
        Leer nombres
        Escribir "Ingrese el precio del producto ", i, ": "
        Leer precios
        Escribir "Ingrese la cantidad del producto ", i, ": "
        Leer cantidades
    FinPara
	
    totalCompra = 0
    Para i = 1 Hasta cantidadProductos Hacer
        totalCompra = totalCompra + (precios * cantidades)
    FinPara
	
    Escribir "El total de la compra es: ", totalCompra
FinAlgoritmo

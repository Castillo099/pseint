Algoritmo numeromaspeque�oentre10
	Definir i, numero, menor Como Real
	escribir "bienvenido a la consultu del numero mas peque�o entre 10"
    Escribir "Ingrese el primer n�mero:"
    Leer menor  // Leer el primer n�mero como el menor inicialmente
	
    Para i = 2 Hasta 10 Hacer
        Escribir "Ingrese el n�mero ", i, ":"
        Leer numero
		
        Si numero < menor Entonces
            menor = numero
        FinSi
    FinPara
	
    Escribir "El n�mero m�s peque�o es: ", menor
FinAlgoritmo

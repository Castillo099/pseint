Algoritmo CalcularPrecioConDescuento
	
    Definir precioOriginal, descuento, precioFinal Como Real
	escribir "bienvenido a el programa de descuento de un producto"
    Escribir "Ingrese el precio original del producto: "
    Leer precioOriginal
	
    Escribir "por  favor ingrese el porcentaje de descuento (sin el s�mbolo %): "
    Leer descuento
	
    descuento <- precioOriginal * (descuento / 100)

    precioFinal <- precioOriginal - descuento
	
    Escribir "El precio final del producto es: ", precioFinal
	
FinAlgoritmo
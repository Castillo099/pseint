Algoritmo CalcularMedia
    Definir n, suma, numero, promedio Como Real
	escribir "bienvenidos a el calculo de la media de numeros" 
    Escribir "Ingrese la cantidad de n�meros: "
    Leer n
	
    suma <- 0
	
    Para i <- 1 Hasta n Hacer
        Escribir "Ingrese el n�mero ", i, ": "
        Leer num
        suma <- suma + num
    FinPara

    promedio <- suma / n
	
    Escribir "La media de los n�meros es: ", promedio
	
FinAlgoritmo
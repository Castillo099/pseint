Algoritmo SumaMultiplos10
Definir suma, num Como Entero
	Escribir "bienvenidos a la suma de multiplos"
    suma <- 0
	
    Para num <- 10 Hasta 1000 Con Paso 10 Hacer
        suma <- suma + num
    FinPara
	
    Escribir "La suma de los m�ltiplos de 10 entre 1 y 1000 es: ", suma
	
FinAlgoritmo
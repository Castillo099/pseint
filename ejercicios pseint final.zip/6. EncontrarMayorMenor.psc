Algoritmo EncontrarMayorMenor
    Definir num, may, men, contador Como Entero
	escribir "bienvenidos a el orden de el numero mayor y menor"
    Escribir "por favor ingrese el primer n�mero: "
    Leer num
    may <- num
    men <- num
	
    Para contador <- 2 Hasta 10 Hacer
        Escribir "por favor ingrese el n�mero ", contador, ": "
        Leer num
        
        Si num > may Entonces
            may <- num
        FinSi
        
        Si num < men Entonces
            men <- num
        FinSi
    FinPara
	
    Escribir "El n�mero mayor es: ", may
    Escribir "El n�mero menor es: ", men
	
FinAlgoritmo
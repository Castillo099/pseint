Algoritmo NumeroMayorA100
	
    Definir num Como Entero
	escribir "bienvenido a la consulta de un numero mayor que 100"
    Escribir "por favor ingrese un n�mero: "
    Leer num

    Si num > 100 Entonces
        Escribir "El n�mero ", num, " es mayor que 100."
    SiNo
        Escribir "El n�mero ", num, " no es mayor que 100."
    FinSi
	
FinAlgoritmo
Algoritmo GeneradorContrasena
    Definir long, i Como Entero
    Definir contrase�a Como Caracter
    Definir caract Como Caracter
	escribir "bienvenido al generador de contrase�as"
	
    caracteres <- "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
	
    Escribir "Ingrese la longitud deseada para la contrase�a: "
    Leer long
	
    contrase�a <- ""
	
    Para i <- 1 Hasta long Hacer
        indiceAleatorio <- Aleatorio(1, Longitud(caracteres))
        contrase�a <- Concatenar(contrase�a, Subcadena(caracteres, indiceAleatorio, indiceAleatorio))
    FinPara
	
    Escribir "La contrase�a generada es: ", contrase�a

FinAlgoritmo
Algoritmo EvaluarCalificaciones
    Definir cantidadCalificaciones, calificacion, suma, promedio Como Real
    Definir aprobatoria, i Como Entero
	
	Escribir "bievenidos ala consulta de aprobado reprobado "
    Escribir "por favor ingrese la cantidad de calificaciones: "
    Leer cantidadCalificaciones
	
    suma <- 0
    aprobatoria <- 0
	
    Para i <- 1 Hasta cantidadCalificaciones Hacer
        Escribir "Ingrese la calificaci�n ", i, ": "
        Leer calificacion
		
        suma <- suma + calificacion
		
        Si calificacion >= 70 Entonces
            Escribir "La calificaci�n ", i, " es APROBADO"
            aprobatoria <- aprobatoria + 1
        SiNo
            Escribir "La calificaci�n ", i, " es REPROBADO"
        FinSi
    FinPara
	
    promedio <- suma / cantidadCalificaciones
	
    Escribir "El promedio de las calificaciones es: ", promedio
	
FinAlgoritmo
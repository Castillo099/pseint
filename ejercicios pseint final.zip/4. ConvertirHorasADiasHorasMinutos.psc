Algoritmo ConvertirHorasADiasHorasMinutos
    Definir horas, dias, horasRestan, min, totalMinu Como Real
	Escribir "bienvenido a la comvercion de horas a dias"
	Escribir "Ingresa el n�mero de horas: "
	
    Leer horas
	
    totalMin = horas * 60

    dias = totalMin / (24 * 60)
    horasRestan = totalMin mod (24 * 60) / 60
    min = totalMin * 60
	
    Escribir "el equivalente en d�as, horas y minutos: "
    Escribir dias, " d�as, ", horasRestan, " horas, ", min, " minutos."
FinAlgoritmo

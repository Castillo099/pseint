Algoritmo VolumenCilindro
    Definir radio, altura, volumen Como Real
	
	escribir "bienvenido a el calculo de el volumen de un cilindro"
    Escribir "por favor ingrese el radio del cilindro: "
    Leer radio
    Escribir "por favor ingrese la altura del cilindro: "
    Leer altura
	
    volumen <- 3.14159 * radio * radio * altura

    Escribir "El volumen del cilindro es: ", volumen
	
FinAlgoritmo
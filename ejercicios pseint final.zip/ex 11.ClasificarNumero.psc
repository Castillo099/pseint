Algoritmo ClasificarNumero
    Definir num Como Entero
	
	Escribir "bienvenido a la calificacion de numeros"
    Escribir "Ingrese un n�mero: "
    Leer num 
	
    Si num < 0 Entonces
        Escribir "El n�mero es negativo."
    SiNo
        Si num = 0 Entonces
            Escribir "El n�mero es cero."
        SiNo
            Si num <= 10 Entonces
                Escribir "El n�mero es peque�o."
            SiNo
                Si num <= 100 Entonces
                    Escribir "El n�mero es mediano."
                SiNo
                    Escribir "El n�mero es grande."
                FinSi
            FinSi
        FinSi
    FinSi
	
FinAlgoritmo
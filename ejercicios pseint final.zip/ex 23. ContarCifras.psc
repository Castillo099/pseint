Algoritmo ContarCifras
    Definir num, contador Como Entero
	escribir "bienvenidos a el contador de cifras de un numero"
    Escribir "por favor ingrese un n�mero entero: "
    Leer num

    contador <- 0

    Mientras num <> 0 Hacer
        contador <- contador + 1
        num <- trunc(num / 10)
    FinMientras
	
    Escribir "El n�mero tiene ", contador, " cifras."
FinAlgoritmo
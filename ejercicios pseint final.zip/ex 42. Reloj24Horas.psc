Algoritmo Reloj24Horas
	
    Definir horas, minutos, segund Como Entero
	
    horas <- 0
    minutos <- 0
    segund <- 0
repetir 
	Escribir "Hora actual: ", horas, ":", minutos, ":", segund
	segund <- segund + 1
	Si segund = 60 Entonces
		segund <- 0
		minutos <- minutos + 1
            Si minutos = 60 Entonces
                minutos <- 0
                horas <- horas + 1
                Si horas = 24 Entonces
				horas <- 0
                FinSi
            FinSi
        FinSi
	Hasta Que hora = 24
        Esperar 1 segundo
FinAlgoritmo
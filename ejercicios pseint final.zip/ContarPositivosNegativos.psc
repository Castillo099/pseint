Algoritmo ContarPositivosNegativos
    Definir num, positivos,negativos Como Entero
	Escribir "bienvenido a el contador de numeros positivos y negativos"
    positivos <- 0
    negativos <- 0
    
    Repetir
        Escribir "por favor ingrese los  n�mero y (para terminar ingrese 0):"
        Leer num
        
        Si num > 0 Entonces
            positivos <- positivos + 1
        Sino
            Si num < 0 Entonces
                negativos <- negativos + 1
            FinSi
        FinSi
    Hasta Que numero = 0
    
    Escribir "la cantidad de n�meros positivos son:", positivos
    Escribir "la cantidad de n�meros negativos son:", negativos
	FinAlgoritmo
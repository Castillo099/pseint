Algoritmo CalcularSalario
    Definir horasTrabajadas, pagoPorHora, salario, horasExtra Como Real
	Escribir "bienvenido a la consulta de su salario semanal"
    Escribir "por favor ingrese las horas trabajadas esta semana: "
    Leer horasTrabajadas
    Escribir "por favor ingrese el pago por hora: "
    Leer pagoPorHora

    Si horasTrabajadas > 40 Entonces
        horasExtra <- horasTrabajadas - 40
    SiNo
        horasExtra <- 0
    FinSi
	
    salario <- (40 * pagoPorHora) + (horasExtra * pagoPorHora * 2)
    Escribir "El salario semanal es: ", salario
	
FinAlgoritmo
Algoritmo SumarPotenciasDeDos
    Definir N, potencia, suma Como Entero
	escribir "bienvenidos a "
    Escribir "Ingrese el valor de N: "
    Leer N
	
    potencia <- 1
    suma <- 0
	
    Para i <- 0 Hasta N Hacer
        suma <- suma + potencia
        potencia <- potencia * 2
    FinPara
	
    Escribir "La suma de las potencias de 2 desde 0 hasta ", N, " es: ", suma
	
FinAlgoritmo
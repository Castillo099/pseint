Algoritmo VolumenCono
	
    Definir radio, altura, volumen Como Real
	escribir "bienvenido a el calculo de el volumen de un cono"
    Escribir "por favor ingrese el radio del cono: "
    Leer radio
    Escribir "por favor ingrese la altura del cono: "
    Leer altura
	
    volumen <- (pi * radio * radio * altura) / 3

    Escribir "El volumen del cono es: ", volumen
	
FinAlgoritmo
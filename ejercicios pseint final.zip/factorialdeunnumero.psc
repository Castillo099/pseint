Algoritmo factorialdeunnumero
	Definir num, factorial Como Entero
    factorial = 1  
	escribir "bienvenido a la consulta del factorial de un numero"
    Escribir "Ingrese un n�mero para calcular su factorial:"
    Leer num
	
    Si num < 0 Entonces
        Escribir "El factorial no est� definido para n�meros negativos."
    Sino
        Para i = 1 Hasta num Hacer
            factorial = factorial * i  
        FinPara
		
        Escribir "El factorial de ", num, " es: ", factorial
    FinSi
FinAlgoritmo

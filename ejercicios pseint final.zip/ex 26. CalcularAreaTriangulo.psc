Algoritmo CalcularAreaTriangulo
    Definir base, altura, area Como Real
	
	Escribir "bienvenidos a calcular el area de un triangulo"
    Escribir "por favor ingrese la base del tri�ngulo: "
    Leer base
    Escribir "por favor ingrese la altura del tri�ngulo: "
    Leer altura
	
    area <- (base * altura) / 2
	
    Escribir "El �rea del tri�ngulo es: ", area
	
FinAlgoritmo
Algoritmo ContieneLetraA
	
    Definir caden Como Cadena
    Definir i, long, contieneA Como Entero
	
    Escribir "Ingrese una cadena: "
    Leer caden
	
    long <- Longitud(caden)
	
    contieneA <- 0
	
    Para i <- 1 Hasta long Hacer
        Si Subcadena(caden, i, 1) = "a" Entonces
            contieneA <- 1
        FinSi
    FinPara
	
    Si contieneA = 1 Entonces
        Escribir "La cadena contiene la letra a."
    SiNo
        Escribir "La cadena no contiene la letra a."
    FinSi
	
FinAlgoritmo
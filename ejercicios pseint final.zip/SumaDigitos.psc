Algoritmo SumaDigitos
    Definir num, suma, digito Como Entero
	Escribir "bienvenido a la suma de digitos"
    Escribir "por favor ingrese un n�mero entero positivo: "
    Leer num
	
    suma <- 0
	
    Mientras num <> 0 Hacer
        digito <- num MOD 10  
        suma <- suma + digito
        num <- trunc(num / 10)  
    FinMientras
	Escribir "La suma de los d�gitos es: ", suma
FinAlgoritmo
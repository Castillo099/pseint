Algoritmo DesviacionEstandar
    Definir num, suma, promedio, varianza, desvia Como Real
    Definir n, i Como Entero
	escribir "bienvenido a el calculo de desviacion estandar"
    Escribir "por favor ingrese la cantidad de n�meros: "
    Leer n
	
    suma <- 0
	
    Para i <- 1 Hasta n Hacer
        Escribir "por favor ingrese el n�mero ", i, ": "
        Leer num
        suma <- suma + num
    FinPara
	
    promedio <- suma / n
	
    varianza <- 0
    Para i <- 1 Hasta n Hacer
        Escribir "por favor ingrese el n�mero ", i, " nuevamente: "
        Leer num
        varianza <- varianza + (num - promedio)^2
    FinPara
    varianza <- varianza / n
	
    desvia <- Raiz(varianza)
	
    Escribir "La desviaci�n est�ndar es: ", desvia
	
FinAlgoritmo
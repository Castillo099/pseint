Algoritmo InvertirNumero
    Definir numero, digito, invertido Como Entero
	escribir "bienvenido a el invertidor de numeros"
    Escribir "por favor ingrese un n�mero entero positivo: "
    Leer numero
	

    invertido <- 0
	
    Mientras numero <> 0 Hacer
        digito <- numero MOD 10
        invertido <- invertido * 10 + digito
        numero <- trunc(numero / 10)
    FinMientras
	
    Escribir "El n�mero invertido es: ", invertido
FinAlgoritmo
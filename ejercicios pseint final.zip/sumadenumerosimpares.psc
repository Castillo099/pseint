Algoritmo sumadenumerosimpares
	definir suma, i, num Como Entero
	escribir "bienvenido a la suma de dos numeros impares "
	escribir "por favor ingresa el numero"
	leer num
	Para i<-1 Hasta 100 Con Paso 1 Hacer
		si i mod 2 <> 0 entonces
			
			suma <- suma + i
			
		FinSi
	Fin Para
	escribir "El resultado de la suma de los n�meros impares entre 1 y 100 es: ", suma
FinAlgoritmo

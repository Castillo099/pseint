Algoritmo GestionInventario
    Definir producto, cantidad, totalProductos, totalCantidad Como Entero
	Escribir "bienvenido a el inventario de sus productos"
    totalProductos <- 0
    totalCantidad <- 0
	
    Repetir
        Escribir "por favor ingrese el c�digo del producto (0 para terminar): "
        Leer producto
		
        Si producto <> 0 Entonces
            Escribir "por favor ingrese la cantidad del producto: "
            Leer cantidad
			
            totalProductos <- totalProductos + 1
            totalCantidad <- totalCantidad + cantidad
        FinSi
    Hasta Que producto = 0
	
    Escribir "Inventario total:"
    Escribir "N�mero de productos: ", totalProductos
    Escribir "Cantidad total de productos: ", totalCantidad
	
FinAlgoritmo

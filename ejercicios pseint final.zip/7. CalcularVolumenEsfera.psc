Algoritmo CalcularVolumenEsfera
    Definir radio, volumen, pir Como Real	
	escribir "bienvenido a el calculo del volumen de una esfera"
    Escribir "por favor ingresa el radio de la esfera: "
    Leer radio
	
	pir = 3.1416
	
    volumen = (4 / 3) * pir * (radio ^ 3)
	
    Escribir "El volumen de la esfera es: ", volumen
FinAlgoritmo

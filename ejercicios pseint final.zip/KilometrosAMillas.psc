Algoritmo KilometrosAMillas
    Definir kilometros, millas Como Real
    Escribir "bienvenido a la conversion de unidades de km a millas"
    Escribir "por favor ingrese la distancia en kil�metros: "
    Leer kilometros

    millas <- kilometros * 0.621371
	
    Escribir kilometros, " kil�metros equivalen a ", millas, " millas"
FinAlgoritmo

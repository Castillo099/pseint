Algoritmo SumaDivisoresPropios
    Definir num, divisor, sumaDivisores Como Entero
	escribir "bienvenido a la suma de divisores propios "
    Escribir "por favor ingrese el enumero: "
    Leer num
	
    sumaDivisores <- 0
	
    Para divisor <- 1 Hasta trunc(num / 2) Hacer
        Si num MOD divisor = 0 Entonces
            sumaDivisores <- sumaDivisores + divisor
        FinSi
    FinPara

    Escribir "La suma de los divisores propios de ", num, " es: ", sumaDivisores
	
FinAlgoritmo
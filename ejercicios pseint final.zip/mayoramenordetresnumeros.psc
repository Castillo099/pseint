Algoritmo mayoramenordetresnumeros
	Definir num1, num2, num3, aux Como Entero
	escribir "bienvenido a el orden de mayor a menor de tres numeros"
    Escribir "Ingrese el primer n�mero: "
    Leer num1
    Escribir "Ingrese el segundo n�mero: "
    Leer num2
    Escribir "Ingrese el tercer n�mero: "
	leer num3
   
    Si num1 < num2 Entonces
        aux <- num1
        num1 <- num2
        num2 <- aux
    FinSi
	
    Si num2 < num3 Entonces
        aux <- num2
        num2 <- num3
        num3 <- aux
    FinSi

    Si num1 < num2 Entonces
        aux <- num1
        num1 <- num2
        num2 <- aux
    FinSi
	
    Escribir "Los n�meros ordenados de mayor a menor son:"
    Escribir num1
    Escribir num2
    Escribir num3
FinAlgoritmo

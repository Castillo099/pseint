Algoritmo divisordeunnumero
	Definir num, l Como Entero
	escribir "bienvenidos a el resultado de los divisores de un numero"
    Escribir "por favor ingrese un n�mero:"
    Leer num
	
    Escribir "Los divisores de ", num, " son:"
	
    Para l = 1 Hasta num Hacer
        Si num mod l = 0 Entonces
            Escribir l
        FinSi
    FinPara
FinAlgoritmo

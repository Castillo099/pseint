Algoritmo DiasEnUnMes
    Definir mes, anio, dias Como Entero
    Escribir "bienvienido a la consulta de los dias de un mes"
    Escribir "por favor ingrese el n�mero del mes (1-12): "
    Leer mes
    Escribir "Ingrese el a�o: "
    Leer anio

    Seg�n mes Hacer
Caso 1, 3, 5, 7, 8, 10, 12:
	dias <- 31
	Escribir "El mes tiene 31 d�as"
Caso 4, 6, 9, 11:
	dias <- 30
	Escribir "El mes tiene 30 d�as"
Caso 2:
	Si ((anio MOD 4 = 0 Y anio MOD 100 <> 0) O anio MOD 400 = 0) Entonces
		dias <- 29
		Escribir "El mes tiene 29 d�as (febrero en un a�o bisiesto)"
	SiNo
		dias <- 28
		Escribir "El mes tiene 28 d�as"
	FinSi
De Otro Modo:
	Escribir "Mes inv�lido"
FinSegun

FinAlgoritmo
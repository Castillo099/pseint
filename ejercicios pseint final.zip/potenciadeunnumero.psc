Algoritmo potenciadeunnumero
	definir base, exponente, resultado Como Entero
	
    Escribir "Ingrese la base: "
    Leer base
    Escribir "Ingrese el exponente: "
    Leer exponente
	
    resultado <- 1
	
    Para i <- 1 Hasta exponente Hacer
        resultado <- resultado * base
    FinPara
	
    Escribir "El resultado de ", base, "^", exponente, " es: ", resultado
FinAlgoritmo


Algoritmo NumerosAleatorios
    Definir num, cantidad, i Como Entero
	Escribir "bienvenido a la secuencia de numeros aleatorios"
    Escribir "por favor ingrese la cantidad de n�meros aleatorios a generar: "
    Leer cantidad
	
    Para i <- 1 Hasta cantidad Hacer
        num <- Aleatorio(1, 100)
        Escribir num
    FinPara
	
FinAlgoritmo
Algoritmo numerosparesyimparesenunconjunto
	definir num,i,par,imp,sp,sim como entero;
	par <- 0;
	im <- 0;
	sp <- 0;
	sim <- 0;
	
	Escribir "Ingresar una cantidad de n�meros: ";
	Leer n;
	
	Para i<-1 Hasta n Hacer
		Escribir i,"Ingresar un n�mero: ";
		Leer num;
		Si num mod 2 =0 Entonces
			par <- par+1;
			sp <- sp+num;
		Sino
			im <- im+1;
		FinSi
	FinPara
	
	Escribir "Numero de Pares: ",par;
	Escribir "Numero de Impares: ",im;

FinAlgoritmo

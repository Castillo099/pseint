Algoritmo multiplicaciondedosnumeros
	definir num1, num2, resultadomultiplicacion Como Entero
	// elaborado por ANDRES FELIPE TRUJILLO
        // 1 SEMESTRE JORNADA NOCTURNA
	escribir "bienvenido a la multiplicacion de dos numeros"
	escribir "por favor ingrese el primer numero "
	leer num1
	escribir "por favor ingrese el segundo numero"
	leer num2 
	// aqui se realiza la operacion de la multiplicacion
	resultadomultiplicacion <- num1 * num2
	escribir "el resultado de la multiplicacion de dos numeros es: ", resultadomultiplicacion
FinAlgoritmo

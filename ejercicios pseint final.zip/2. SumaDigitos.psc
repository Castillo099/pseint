Algoritmo SumaDigitos
    Definir num, digito, suma Como Entero
    escribir "bienvenidos a la suma de digitos"
    Escribir "Ingrese un n�mero entero: "
    Leer num
    
    suma <- 0
    
    Mientras num <> 0 Hacer
        digito <- num MOD 10
        suma <- suma + digito
        num<- trunc(num / 10)
    FinMientras
    
    Escribir "La suma de los d�gitos es: ", suma
FinAlgoritmo
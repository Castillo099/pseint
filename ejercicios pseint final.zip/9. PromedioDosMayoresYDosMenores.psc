Algoritmo PromedioDosMayoresYDosMenores
    Definir num1, num2, num3, num4, num5 Como Real
    Definir mayor1, mayor2, menor1, menor2, promedio, sumaMenores, sumaMayores Como Real
	
	Escribir "bienvenidos al promedio de mayores y menores"
	
    Escribir "por favor ingresa el primer n�mero: "
    Leer num1
    Escribir "por favor ingresa el segundo n�mero: "
    Leer num2
    Escribir "por favor ingresa el tercer n�mero: "
    Leer num3
    Escribir "por favor ingresa el cuarto n�mero: "
    Leer num4
    Escribir "por favor ingresa el quinto n�mero: "
    Leer num5
	
    mayor1 = -999999
    mayor2 = -999999
    menor1 = 999999
    menor2 = 999999
	
    Si num1 > mayor1 Entonces
        mayor2 = mayor1
        mayor1 = num1
	FinSi
	Si num1 > mayor2 Entonces
        mayor2 = num1
    FinSi
	
    Si num2 > mayor1 Entonces
        mayor2 = mayor1
        mayor1 = num2
		finsi
		 Si num2 > mayor2 Entonces
        mayor2 = num2
    FinSi
	
    Si num3 > mayor1 Entonces
        mayor2 = mayor1
        mayor1 = num3
	FinSi
	   Si num3 > mayor2 Entonces
        mayor2 = num3
    FinSi
	
    Si num4 > mayor1 Entonces
        mayor2 = mayor1
        mayor1 = num4
	FinSi
		Si num4 > mayor2 Entonces
        mayor2 = num4
    FinSi
	
    Si num5 > mayor1 Entonces
        mayor2 = mayor1
        mayor1 = num5
	FinSi
		si num5 > mayor2 Entonces
        mayor2 = num5
    FinSi
	
    Si num1 < menor1 Entonces
        menor2 = menor1
        menor1 = num1
	FinSi
		Si num1 < menor2 Entonces
        menor2 = num1
    FinSi
	
    Si num2 < menor1 Entonces
        menor2 = menor1
        menor1 = num2
	FinSi
		Si num2 < menor2 Entonces
        menor2 = num2
    FinSi
	
    Si num3 < menor1 Entonces
        menor2 = menor1
        menor1 = num3
	FinSi
		Si num3 < menor2 Entonces
        menor2 = num3
    FinSi
	
	Si num4 < menor1 Entonces
        menor2 = menor1
        menor1 = num4
   finsi
	  Si num4 < menor2 Entonces
        menor2 = num4
    FinSi
	
	Si num5 < menor1 Entonces
        menor2 = menor1
        menor1 = num5
	FinSi
	
		Si num5 < menor2 Entonces
        menor2 = num5
    FinSi
	
    sumaMenores = menor1 + menor2
    sumaMayores = mayor1 + mayor2
	
    promedio = (sumaMenores + sumaMayores) / 4
	
    Escribir "El promedio de los dos mayores y dos menores es: ", promedio
FinAlgoritmo

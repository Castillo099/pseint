Algoritmo BotellasParaPiscina
	
    Definir capacidadPiscina, botellasNecesarias Como Entero
	escribir "bienvenidos a la consulta decuantas botellas de 1 litro se nesesita para llenar una picina"
    Escribir "por favor ingrese la capacidad de la piscina en litros: "
    Leer capacidadPiscina

    botellasNecesarias <- capacidadPiscina
	
    Escribir "Necesitar�s ", botellasNecesarias, " botellas de 1 litro para llenar la piscina."
	
FinAlgoritmo
Algoritmo resultadocalificacion
	definir cal1, cal2, cal3, cal4, cal5, suma, promedio Como Real
	escribir "bienvenido al resultado de su calificacion "
	
	escribir"por favor ingrese su primera calificacion"
	leer cal1
	escribir"por favor ingrese su segundo calificacion"
	leer cal2
	escribir"por favor ingrese su tercer calificacion"
	leer cal3
	escribir"por favor ingrese su cuarto calificacion"
	leer cal4
	escribir"por favor ingrese su quinto calificacion"
	leer cal5
	
	suma = cal1 + cal2 + cal3 + cal4 + cal5
	promedio = suma / 5
	
	escribir "su calificacion es:", promedio
	
FinAlgoritmo

Algoritmo ContarPalabras
    Definir texto, palabra, contador Como Caracter

    Escribir "Ingrese el texto: "
    Leer texto
	
    contadorPalabras <- 0
	
    Para i <- 1 Hasta Longitud(texto) Hacer
        Si Subcadena(texto, i, i) = " " Y (i = 1 O Subcadena(texto, i-1, i-1) <> " ") Entonces
            contadorPalabras <- contadorPalabras + 1
        FinSi
    FinPara
	
    Si Subcadena(texto, Longitud(texto), Longitud(texto)) <> " " Entonces
        contadorPalabras <- contadorPalabras + 1
    FinSi
	
    Escribir "La cantidad de palabras en el texto es: ", contadorPalabras
	
FinAlgoritmo
Algoritmo AdivinaElNumero
    Definir numeroAleatorio, numeroUsuario, intentos Como Entero
	escribir "bienvenido a el juego adivina el numero"
    Escribir "Piensa en un n�mero entre 1 y 100..."
    numeroAleatorio <- Aleatorio(1, 100)
	
    intentos <- 0

    Repetir
        Escribir "Ingresa tu n�mero: "
        Leer numeroUsuario
		
        intentos <- intentos + 1
		
        Si numeroUsuario > numeroAleatorio Entonces
            Escribir "El n�mero es menor."
        SiNo
            Si numeroUsuario < numeroAleatorio Entonces
                Escribir "El n�mero es mayor."
            SiNo
                Escribir "�Felicitaciones! Adivinaste el n�mero en ", intentos, " intentos."
            FinSi
        FinSi
    Hasta Que Falso
	
FinAlgoritmo
Algoritmo adivinaelnumero
	
    Definir numeroAleatorio, numeroUsuario Como Entero
	
    numeroAleatorio <- Aleatorio(1, 100)
	
	escribir"bienvenido a  el juego de numera aleatorios"
    Escribir "piensa es un numero aleatorio entre 1 y 100."
    
    Repetir
        Escribir "Adivina el n�mero: "
        Leer numeroUsuario
		
        Si numeroUsuario < numeroAleatorio Entonces
            Escribir "El n�mero es mayor."
        SiNo
            Si numeroUsuario > numeroAleatorio Entonces
                Escribir "El n�mero es menor."
            SiNo
                Escribir "�Felicitaciones! Adivinaste el n�mero."
            FinSi
        FinSi
    Hasta Que numeroUsuario = numeroAleatorio
	
FinAlgoritmo
Algoritmo TeoremaPitagoras
    Definir catetoopu, catetoady, hipotenusa Como Real
	
	escribir "bienvenido a el teorema de pitagoras"
    Escribir "por favor ingrese la longitud del primer cateto opuesto: "
    Leer catetoopu
    Escribir "por favor ingrese la longitud del segundo cateto adyacente: "
    Leer catetoady
	
    hipotenusa <- Raiz(catetoopu^2 + catetoady^2)
	
    Escribir "La longitud de la hipotenusa es: ", hipotenusa
	
FinAlgoritmo
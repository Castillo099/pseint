Algoritmo MaquinaExpendedora
	
    Definir precioProducto, dineroIngresado, cambio, billetes, monedas Como Entero
	
    precioProducto <- 5000
	escribir "bienvenido a maquina expendedora"
    Escribir "por favor ingrese el dinero para el producto (", precioProducto, " unidades): "
    Leer dineroIngresado
	
    cambio <- dineroIngresado - precioProducto
	
    Si cambio >= 0 Entonces
        Escribir "Su cambio es: ", cambio, " unidades"
        billetes <- cambio / 2
        monedas <- cambio MOD 2
        Escribir "Billetes de 2: ", billetes
        Escribir "Monedas de 1: ", monedas
    SiNo
        Escribir "Dinero insuficiente. Por favor, ingrese m�s dinero."
    FinSi
	
FinAlgoritmo
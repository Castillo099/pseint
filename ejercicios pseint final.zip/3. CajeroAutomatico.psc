Proceso CajeroAutomatico
    Definir saldo, cantidad Como Real
    Definir opci Como Entero
    saldo <- 15000.0 
	
        Escribir "Bienvenido al Cajero Autom�tico"
        Escribir "por favor seleccione una opci�n:"
        Escribir "1. Verificar saldo"
        Escribir "2. Retirar dinero"
        Escribir "3. Depositar dinero"
        Escribir "4. Salir"
        Leer opci
		
        Segun opci Hacer
            1:
                Escribir "Su saldo actual es: $", saldo
				
            2:
                Escribir "Ingrese la cantidad a retirar:"
                Leer cantidad
				
                Si cantidad > saldo Entonces
                    Escribir "Saldo insuficiente. No se puede retirar esa cantidad."
                Sino
                    saldo <- saldo - cantidad
                    Escribir "Retiro exitoso. Su nuevo saldo es: $", saldo
                FinSi
				
            3:
                Escribir "Ingrese la cantidad a depositar:"
                Leer cantidad
				
                saldo <- saldo + cantidad
                Escribir "Dep�sito exitoso. Su nuevo saldo es: $", saldo
				
            4:
                Escribir "Gracias por usar el Cajero Autom�tico. �Hasta luego!"
            De Otro Modo:
                Escribir "Opci�n no v�lida. Intente de nuevo."
        Fin Segun
FinFuncion

   
	Fin Proceso

Algoritmo a�obisiesto
	definir a�o Como Entero
	Escribir "bienvenido a la consulta de un a�o bisiesto"
	escribir "par favor ingrese el a�o"
	leer a�o
	Si ((a�o mod 4 = 0) Y (a�o MOD 365 <> 0)) Entonces
		escribir "el a�o es bisiesto"
	SiNo
		escribir "el a�o no es biciesto"
	Fin Si
FinAlgoritmo

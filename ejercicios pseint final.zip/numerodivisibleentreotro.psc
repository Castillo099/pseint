Algoritmo numerodivisibleentreotro
	Definir num1, num2 Como Entero
	escribir "bienvenido al resultado de un n�mero es divisible entre otro n�mero"
    Escribir "Ingrese el primer n�mero (dividendo):"
    Leer num1
    Escribir "Ingrese el segundo n�mero (divisor):"
    Leer num2
	
    Si num2 = 0 Entonces
        Escribir "No se puede dividir entre cero."
    Sino
        Si num1 mod num2 = 0 Entonces
            Escribir num1, " es divisible entre ", num2
        Sino
            Escribir num1, " no es divisible entre ", num2
        FinSi
    FinSi
FinAlgoritmo

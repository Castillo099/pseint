Algoritmo divisiondedosnumeros
	definir num1, num2, resultadodivision Como Entero
	// elaborado por ANDRES FELIPE TRUJILLO
        // 1 SEMESTRE JORNADA NOCTURNA
	escribir "bienvenido a la divicion de dos numeros"
	escribir "por favor ingrese el primer numero "
	leer num1
	escribir "por favor ingrese el segundo numero"
	leer num2 
	// aqui se realiza la operacion de la divicion
	resultadodivision <- num1 / num2
	escribir "el resultado de la suma de dos numeros es: ", resultadodivision
FinAlgoritmo

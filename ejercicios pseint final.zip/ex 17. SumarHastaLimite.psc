Algoritmo SumarHastaLimite
    Definir numero, suma, limite Como Entero
	
	escribir "bievenidos a la suma de numeros hasta un limite"
    Escribir "por favor ingrese el l�mite de la suma: "
    Leer limite
	
    suma <- 0
	
    Repetir
        Escribir "por favor ingrese un n�mero: "
        Leer numero
        suma <- suma + numero
    Hasta Que suma > limite

    Escribir "La suma total es: ", suma
	
FinAlgoritmo
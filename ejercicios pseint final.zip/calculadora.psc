Algoritmo calculadora
	Definir num1, num2, resultado Como Real
        Definir op Como entero
        // elaborado por ANDRES FELIPE TRUJILLO
        // 1 SEMESTRE JORNADA NOCTURNA
	escribir "bienvenidos a la calculadora basica"
	
	continuar = "1"
	
     Mientras continuar = "1" O continuar = "1" Hacer
     Escribir "Ingrese el primer n�mero: "
     Leer num1
	 Escribir "Ingrese el segundo n�mero: "
     Leer num2
	 
	 Escribir "Seleccione la operaci�n que desea realizar: "
	 Escribir "1: multiplicacion"
	 Escribir "2: Resta"
	 Escribir "3: suma"
	 Escribir "4: Divisi�n"
     
     Leer op
	 
		Segun op Hacer
        1:
            resultado = num1 * num2
            Escribir "el resultado de la multiplicacion es: ", resultado
        2:
            resultado = num1 - num2
            Escribir "el resultado de la resta es : ", resultado
        3:
            resultado = num1 * num2
            Escribir "el resultado de la suma es: ", resultado
        4:
            resultado = num1 / num2
			escribir "el resultado de la divicion es: ", resultado
        
        De Otro Modo:
            Escribir "la Operaci�n no es v�lida."
	 Fin Segun
	 
	  Escribir "�Desea realizar otra operaci�n? 1 Si 0 No: "
	  Leer continuar
	  
  Fin Mientras
 
	Escribir "Gracias por usar la calculadora ."
FinAlgoritmo

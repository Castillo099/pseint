Algoritmo CalcularAreaCirculo
    Definir radio, area, pir Como Real
	Escribir "bienvenido a el calculo de el area de un circulo"
	Escribir "Ingresa el radio del c�rculo: "
    Leer radio
	
    pir = 3.1416

    area = pi * (radio ^ 2)
	
    Escribir "El �rea del c�rculo es: ", area
FinAlgoritmo

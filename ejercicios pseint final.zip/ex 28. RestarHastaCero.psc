Algoritmo RestarHastaCero
    Definir num Como Entero
	Escribir "bienvenidos a la resta de numeros hasta cero"
    Escribir "por favor ingrese un n�mero entero positivo: "
    Leer num
	
    Mientras num < 0 Hacer
        Escribir "El n�mero debe ser positivo. Intente nuevamente:"
        Leer num
    FinMientras

    Mientras num >= 0 Hacer
        Escribir num
        num <- num - 1
    FinMientras
	
FinAlgoritmo
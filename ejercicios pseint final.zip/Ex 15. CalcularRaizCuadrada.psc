Algoritmo CalcularRaizCuadrada
    Definir numero, raizCuadrada Como Real
	escribir "bienvenidos a el calculo de la raiz cuadrada de un numero"
    Escribir "por favor ingrese un n�mero: "
    Leer numero
	
    raizCuadrada <- Raiz(numero)
	
    Escribir "La ra�z cuadrada de ", numero, " es: ", raizCuadrada
	FinAlgoritmo
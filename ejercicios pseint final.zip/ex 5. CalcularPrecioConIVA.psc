Algoritmo CalcularPrecioConIVA
    Definir precio_base, iva, precio_final Como Real
	escribir "bienvenido a el calculo del iva de un producto"
    Escribir "por favor ingrese el precio base del producto: "
    Leer precio_base
	
    iva <- precio_base * 0.21
	
    precio_final <- precio_base + iva
	
    Escribir "El precio final con IVA es: ", precio_final
	
FinAlgoritmo
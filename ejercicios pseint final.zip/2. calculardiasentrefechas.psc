Algoritmo calculardiasentrefechas
	definir dd1, mm1, aaaa1, dd2, mm2, aaaa2, totaldias1, totaldias2, diferencia como entero
	
	Escribir "bienvenido a el calculo de dias entre fechas"
	Escribir "por favor ingrese la fecha"
    Escribir "dia:";leer dd1
	Escribir "mes:";leer mm1
	Escribir "a�o:";leer aaaa1
	
	Escribir "por favor imgrese  la segunda fecha"
    Escribir "dia:";leer dd2
	Escribir "mes:";leer mm2
	Escribir "a�o:";leer aaaa2
	
	totaldias1 <- dd1 + (mm1 * 30) + (aaaa1 * 365)
	totaldias2 <- dd2 + (mm2 * 30) + (aaaa2 * 365)
	
	diferencia = abs(totaldias1 - totaldias2)
	
FinAlgoritmo

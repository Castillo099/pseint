Algoritmo GenerarNumerosTriangulares
    Definir Num, i, nuntri Como Entero
	escribir "bienvenido a el generador de numeros triangulares"
    Escribir "Ingresa el n�mero de t�rminos que deseas generar: "
    Leer Num
	
    numeroTriangular = 0
	
    Para i = 1 Hasta Num Con Paso 1 Hacer
        numtri = (i * (i + 1)) / 2
        Escribir "N�mero triangular ", i, ": ", numtri
    FinPara
FinAlgoritmo

Algoritmo MultiplosDeCinco
    Definir num Como Entero
	
	Escribir "bievenidos a los multiplos de 5"
	escribir "los multiplos de 5 son:"
    Para num <- 1 Hasta 50 Hacer
        Si num MOD 5 = 0 Entonces
            Escribir num
        FinSi
    FinPara
	
FinAlgoritmo
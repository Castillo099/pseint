Algoritmo paroimpar
	Definir num Como Entero
	escribir "bienvenido a la consulta de par o impar"
	Escribir "Por favor ingrese el primer n�mero, para saber si es Par o Impar"
	Leer num
	
	Si num mod 2 = 0 Entonces
		Escribir "El n�mero es Par"
	SiNo
		Escribir "El n�mero es Impar"
	Fin Si
FinAlgoritmo

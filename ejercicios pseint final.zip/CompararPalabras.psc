Algoritmo CompararPalabras
	Definir palabral, palabra2 Como Cadena;
	
	Escribir "Bienvenido a comparaci�n de palabras";
	Escribir "Ingresa la primera palabra";
	Leer palabral;
	Escribir "Ingresa la segunda palabra";
	Leer palabra2;
	
	Si palabra Entonces
		Escribir "Las palabras son iguales";
	SiNo
		Escribir "Las palabras son diferentes";
		
	Fin Si
	Escribir palabral, " tiene", Longitud(palabral), " caracteres";
	Escribir palabra2, "tiene", Longitud(palabra2), " caracteres";
	
FinAlgoritmo
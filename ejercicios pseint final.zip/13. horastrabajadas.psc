Algoritmo horastrabajadas
    Definir dias, horas, minutos, tarifa, minutosTotales, pagoTotal Como Real
	Escribir "bienvenido a el calculo de horas trabajadas"
    Escribir "Ingrese los d�as trabajados: "
    Leer dias
    Escribir "Ingrese las horas trabajadas: "
    Leer horas
    Escribir "Ingrese los minutos trabajados: "
    Leer minutos
    Escribir "Ingrese la tarifa por hora: "
    Leer tarifa
	
    minutosTotales <- (dias * 24 * 60) + (horas * 60) + minutos
	
    pagoTotal <- (minutosTotales / 60) * tarifa
	
    Escribir "El pago total es: ", pagoTotal
	
FinAlgoritmo
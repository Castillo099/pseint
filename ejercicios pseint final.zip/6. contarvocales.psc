Algoritmo contarvocales
	Definir palabra Como Caracter
	Definir n,x,c Como Entero
	escribir "bienvenido la consulta de vocales en una frase"
	Escribir "por favor ingrese la frase"
	leer palabra
	n = Longitud(palabra)
	x = 1
	c = 0
	Mientras x <= n  Hacer
		x = x + 1
		Segun Subcadena(palabra, x, x) Hacer
			"a" o "A":
				c = c + 1
			"E" o "E":
				c = c + 1
			"i" o "I":
				C = C + 1
			"o" o "O":
				C = C + 1
			"u" o "U":
				C = C + 1
		Fin Segun
		X = X + 1
	Fin Mientras
	
	Escribir "La frase ",palabra," tiene ",c," Vocales"
FinAlgoritmo

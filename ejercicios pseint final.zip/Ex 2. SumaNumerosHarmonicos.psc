Algoritmo SumaNumerosHarmonicos
    Definir N, i Como Entero
    Definir suma, termino Como Real
	escribir "bienvenidos a la suma de numeros harmonicos"
    Escribir "por favor ingrese un numero: "
    Leer N
	
    suma <- 0
	
    Para i <- 1 Hasta N Hacer
        termino <- 1 / i
        suma <- suma + termino
    FinPara
	
    Escribir "La suma de los primeros ", N, " n�meros arm�nicos es: ", suma
	
FinAlgoritmo

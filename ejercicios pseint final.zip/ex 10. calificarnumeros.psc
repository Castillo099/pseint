Algoritmo ClasificarNumeros
    Definir cantidadNumeros, num, contadorPares, contadorImpares Como Entero
	
    Escribir "Ingrese la cantidad de n�meros: "
    Leer cantidadNumeros
	
    contadorPares <- 0
    contadorImpares <- 0

    Para i <- 1 Hasta cantidadNumeros Hacer
        Escribir "Ingrese el n�mero ", i, ": "
        Leer num

        Si num MOD 2 = 0 Entonces
            contadorPares <- contadorPares + 1
        SiNo
            contadorImpares <- contadorImpares + 1
        FinSi
    FinPara
	
    Escribir "Cantidad de n�meros pares: ", contadorPares
    Escribir "Cantidad de n�meros impares: ", contadorImpares
	
FinAlgoritmo
Algoritmo ContarDigitos
    Definir numero, contadorDigitos Como Entero
	Escribir "bienvenido a el programa de contar digitos"
    Escribir "por favor ingrese un n�mero: "
    Leer numero

    contadorDigitos <- 0

    Mientras numero <> 0 Hacer
        contadorDigitos <- contadorDigitos + 1
        numero <- trunc(numero / 10)
    FinMientras
	
    Escribir "El n�mero tiene ", contadorDigitos, " d�gitos."
	
FinAlgoritmo
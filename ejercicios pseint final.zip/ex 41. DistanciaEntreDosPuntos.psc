Algoritmo DistanciaEntreDosPuntos
	
    Definir x1, y1, x2, y2, distancia Como Real
	
	Escribir "bienvenidos a calcular la distancia entre dos puntos"
    Escribir "por favor ingrese la coordenada x del primer punto: "
    Leer x1
    Escribir "por favor ingrese la coordenada y del primer punto: "
    Leer y1
    Escribir "por favro ingrese la coordenada x del segundo punto: "
    Leer x2
    Escribir "por favor ingrese la coordenada y del segundo punto: "
    Leer y2
	
    distancia <- Raiz((x2 - x1)^2 + (y2 - y1)^2)

    Escribir "La distancia entre los dos puntos es: ", distancia
	
FinAlgoritmo
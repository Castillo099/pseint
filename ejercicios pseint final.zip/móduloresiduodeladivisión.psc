Algoritmo m�duloresiduodeladivisi�n
	Definir num1, num2, resultadoresiduo Como Entero
	// elaborado por ANDRES FELIPE TRUJILLO
        // 1 SEMESTRE JORNADA NOCTURNA
	escribir "bienvenidos al m�dulo residuo de la divisi�n de dos numeros"
	Escribir "por favor Ingrese el primer n�mero"
    Leer num1
    Escribir "por favor ingrese el segundo n�mero" 
    Leer num2
	// aqui se realiza la operacion del residuo de la divicion
    resultadoresiduo <- num1 mod num2
    Escribir "El m�dulo (residuo) de la divisi�n es: ", resultadoresiduo
FinAlgoritmo

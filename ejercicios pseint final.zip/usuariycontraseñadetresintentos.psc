Algoritmo usuariycontrase�adetresintentos
	definir sesion, intentos Como Entero
	escribir "bienvenido a la validacion de su usuario y contrase�a"
	Escribir "tiene tres intentos para validar "
	sesion <- 0
	intentos <- 0
	Mientras (intentos <3 y sesion == 0) Hacer
		escribir "por favor ingrese el usuario"
		leer usuario  
		escribir "por favor ingrese la contrase�a"
		leer contrase�a
		si (usuario=="felipecastillo") Entonces
			si (contrase�a=="felipe0909") Entonces
				escribir "bienvenido al sistema"
				sesion <- 1
			SiNo
				Escribir "la contrase�a es incorrecta"
				intentos<- 1
				Limpiar Pantalla
			FinSi
		SiNo
			
			escribir "el usuario es incorrecto"
			intentos<-intentos+1
			Limpiar Pantalla
		FinSi
	Fin Mientras
	si (intentos==3)entonces
		escribir "usuario bloqueado,utilizo tres intentos"
	FinSi
FinAlgoritmo

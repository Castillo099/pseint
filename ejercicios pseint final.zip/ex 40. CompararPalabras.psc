Algoritmo CompararPalabras
    Definir palabra1, palabra2 Como Cadena
	
	Escribir "bienvenidos a el comparador de palabras"
    Escribir "por favor ingrese la primera palabra: "
    Leer palabra1
    Escribir "por favor ingrese la segunda palabra: "
    Leer palabra2
	
    Si palabra1 = palabra2 Entonces
        Escribir "Las palabras son iguales."
    SiNo
        Escribir "Las palabras son diferentes."
    FinSi
	
FinAlgoritmo
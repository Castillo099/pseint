Algoritmo Cronometro
    Definir Num, segund Como Entero
	escribir "bienvenido a el cronometro "
    Escribir "por favor ingrese el tiempo m�ximo en segundos: "
    Leer Num
    segund <- 0
	
    Mientras segund <= N Hacer
        Escribir "Segundos: ", segund
      Esperar 1 segundo 
        segund <- segund + 1
    FinMientras
	
    Escribir "�Tiempo cumplido!"
	
FinAlgoritmo
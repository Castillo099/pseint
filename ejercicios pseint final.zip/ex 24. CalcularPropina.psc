Algoritmo CalcularPropina
    Definir totalCuenta, propina, totalPagar Como Real
	escribir "bienvenido a el calculo de su propina"
    Escribir "Ingrese el total de la cuenta: "
    Leer totalCuenta
	
    Escribir "Qu� tan bueno fue el servicio? "
	escribir "1: Malo"
	escribir "2: Bueno"
	Escribir "3: Excelente"
    Leer opcion
	
Seg�n opcion Hacer
	1:
	propina <- totalCuenta * 0  
	2:
	propina <- totalCuenta * 0.10
	3:
	propina <- totalCuenta * 0.15
De Otro Modo:
	Escribir "Opci�n inv�lida."
FinSeg�n


totalPagar <- totalCuenta + propina


Escribir "La propina es: $", propina
Escribir "El total a pagar es: $", totalPagar

FinAlgoritmo
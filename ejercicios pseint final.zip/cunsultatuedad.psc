Algoritmo cunsultatuedad
	definir edad como entero 
	escribir "bienbenido a la consulta de su edad "
	escribir "porfavor ingrese su edad"
	leer edad 
	Si edad >= 18 Entonces
		escribir "usted es mayor de edad"
	SiNo
		escribir"usted es menor de edad"
	Fin Si
FinAlgoritmo

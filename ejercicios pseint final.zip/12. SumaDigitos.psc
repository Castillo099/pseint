Algoritmo SumaDigitos
    Definir num, suma, digito Como Entero
	escribir "bienvenido a la suma de dijitos "
    Escribir "por favo ingrese un n�mero entero positivo: "
    Leer num
	
    suma <- 0

    Mientras num <> 0 Hacer
        digito <- num MOD 10
        suma <- suma + digito 
        num <- trunc(num / 10) 
    FinMientras
	
    Escribir "La suma de los d�gitos es: ", suma
	
FinAlgoritmo
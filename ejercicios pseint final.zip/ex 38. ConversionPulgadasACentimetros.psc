Algoritmo ConversionPulgadasACentimetros
	
    Definir pulgadas, centimetros Como Real
	Escribir "bienvenido a el comvertidorde pulgadas a centimetros"
    Escribir "por favor ingrese la medida en pulgadas: "
    Leer pulgadas

    centimetros <- pulgadas * 2.54

    Escribir pulgadas, " pulgadas equivalen a ", centimetros, " cent�metros"
	
FinAlgoritmo
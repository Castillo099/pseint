Algoritmo CalcularIMC
    Definir peso, altura, IMC Como Real
	
	Escribir "bienvenido a la consulta de su IMC"
    Escribir "Ingrese su peso en kilogramos: "
    Leer peso
    Escribir "Ingrese su altura en metros: "
    Leer altura

    IMC <- peso / (altura * altura)

    Escribir "Su IMC es: ", IMC
	
    Si IMC < 18.5 Entonces
        Escribir "Usted tiene bajo peso."
    SiNo
        Si IMC >= 18.5 Y IMC <= 24.9 Entonces
            Escribir "Usted tiene un peso normal."
        SiNo
            Si IMC >= 25 Y IMC <= 29.9 Entonces
                Escribir "Usted tiene sobrepeso."
            SiNo
                Escribir "Usted tiene obesidad."
            FinSi
        FinSi
    FinSi
	
FinAlgoritmo
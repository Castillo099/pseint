Algoritmo MediaGeometrica
    Definir num, suma, contador, mediaGeo Como Real
	escribir "bienvenido a el calculo de la media geometrica"
    suma <- 1
    contador <- 0

    Repetir
        Escribir "por favor ingrese un n�mero "
		escribir "(ingese 0 para terminar):"
        Leer num
		
        Si num <> 0 Entonces
            suma <- suma * num
            contador <- contador + 1
        FinSi
    Hasta Que num = 0
	
    Si contador > 0 Entonces
        mediaGeo <- suma ^ (1 / contador)
        Escribir "La media geom�trica es: ", mediaGeo
    SiNo
        Escribir "No se ingresaron n�meros v�lidos."
    FinSi
	
FinAlgoritmo
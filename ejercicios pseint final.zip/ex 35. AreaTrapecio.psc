Algoritmo AreaTrapecio
    Definir baseMayor, baseMenor, altura, area Como Real
	
	Escribir "bienvenido a el calculo de el area de un trapecio"
    Escribir "por favor ingrese la base mayor del trapecio: "
    Leer baseMayor
    Escribir "por favor ingrese la base menor del trapecio: "
    Leer baseMenor
    Escribir "por favor ingrese la altura del trapecio: "
    Leer altura

    area <- ((baseMayor + baseMenor) * altura) / 2

    Escribir "El �rea del trapecio es: ", area
	
FinAlgoritmo
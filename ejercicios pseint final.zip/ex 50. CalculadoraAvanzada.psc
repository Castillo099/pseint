Algoritmo CalculadoraAvanzada
	
    Definir numero1, numero2, resultado Como Real
    Definir operacion Como Caracter
	
    Escribir "Bienvenido a la calculadora avanzada"
	
    Repetir
        Escribir "Ingrese la operaci�n (+, -, *, /, ^ para potencia, sqrt para ra�z cuadrada, log para logaritmo natural): "
        Leer operacion
		
        Si operacion <> "sqrt" Y operacion <> "log" Entonces
            Escribir "Ingrese el primer n�mero: "
            Leer numero1
            Escribir "Ingrese el segundo n�mero: "
            Leer numero2
        FinSi
		
        Seg�n operacion Hacer
	Caso '+':
		resultado <- numero1 + numero2
	Caso '-':
		resultado <- numero1 - numero2
	Caso '*':
		resultado <- numero1 * numero2
	Caso '/':
		Si numero2 = 0 Entonces
			Escribir "Error: Divisi�n por cero"
		SiNo
			resultado <- numero1 / numero2
		FinSi
	Caso '^':
		resultado <- numero1 ^ numero2
	Caso 'sqrt':
		Escribir "Ingrese el n�mero para calcular la ra�z cuadrada: "
		Leer numero1
		resultado <- Raiz(numero1) 
	Caso 'log':
		Escribir "Ingrese el n�mero para calcular el logaritmo natural: "
		Leer numero1
		resultado <- Ln(numero1) 
	De Otro Modo:
		Escribir "Operaci�n inv�lida"
FinSegun

Escribir "El resultado es: ", resultado

Escribir "�Deseas realizar otra operaci�n? (S/N): "
Leer respuesta
Hasta Que respuesta <> "S" Y respuesta <> "s"

FinAlgoritmo

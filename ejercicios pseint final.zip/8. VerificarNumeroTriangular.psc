Algoritmo VerificarNumeroTriangular
    Definir num, n, numtri Como Entero
    Definir encontrado Como Logico
    Escribir "bienvenido a la verificacion de numeros truangulares"
    Escribir "por favor ingresa un n�mero para verificar si es triangular: "
    Leer num
	
	encontrado = Falso
	
    n = 1
	
    Mientras numtri < num Hacer
        numtri = (n * (n + 1)) / 2

        Si numtri = num Entonces
            encontrado = Verdadero
        FinSi
        n = n + 1
    FinMientras
	
    Si encontrado Entonces
        Escribir num, " es un n�mero triangular."
    Sino
        Escribir num, " no es un n�mero triangular."
    FinSi
FinAlgoritmo

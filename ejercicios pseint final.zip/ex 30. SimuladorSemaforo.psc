Algoritmo SimuladorSemaforo
    Definir color Como Caracter
	Escribir "bienvenido a la simulacion de el semaforo"
    Escribir "por favor ingrese el color del sem�foro: "
	Escribir "verde"
	Escribir "amarillo"
	Escribir "rojo"
    Leer color

    Seg�n color Hacer
		Caso "verde":
		Escribir "El sem�foro est� en verde. Puede avanzar."
		Caso "amarillo":
		Escribir "El sem�foro est� en amarillo. Precauci�n."
		Caso "rojo":
		Escribir "El sem�foro est� en rojo. Det�ngase."
De Otro Modo:
	Escribir "Color inv�lido. Los colores v�lidos son: verde, amarillo, rojo."
FinSeg�n

FinAlgoritmo
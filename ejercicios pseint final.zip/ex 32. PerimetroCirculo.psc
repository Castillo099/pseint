Algoritmo PerimetroCirculo
    Definir radio, perimetro Como Real
	
	Escribir "bienvenido a calcular el perimetro de un circulo"
    Escribir "por favor ingrese el radio del c�rculo: "
    Leer radio
	
    perimetro <- 2 * pi * radio
	
    Escribir "El per�metro del c�rculo es: ", perimetro
	
FinAlgoritmo
Algoritmo CalcularPerimetroRectangulo
    Definir base, altura, perimetro Como Real
	escribir "bienvenido a el calculo de el perimetro de un regtangulo"
    Escribir "por favor ingrese la base del rect�ngulo: "
    Leer base
    Escribir "por favor ingrese la altura del rect�ngulo: "
    Leer altura
	
    perimetro <- 2 * (base + altura)
	
    Escribir "El per�metro del rect�ngulo es: ", perimetro
	
FinAlgoritmo
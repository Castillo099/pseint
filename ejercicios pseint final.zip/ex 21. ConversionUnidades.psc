Algoritmo ConversionUnidades
    Definir opcio, valo, resultado Como Real
	
    Escribir "Seleccione la conversi�n deseada:"
    Escribir "1. Metros a kil�metros"
    Escribir "2. Kil�metros a metros"
    Escribir "3. Gramos a kilogramos"
    Escribir "4. Kilogramos a gramos"
    Leer opcio
	
    Escribir "Ingrese el valor a convertir: "
    Leer valo
	
    Seg�n opcio Hacer
	1: 
		resultado <- valo / 1000
		Escribir valo, " metros equivalen a ", resultado, " kil�metros."
	2:
		resultado <- valo * 1000
		Escribir valo, " kil�metros equivalen a ", resultado, " metros."
	3:
		resultado <- valo / 1000
		Escribir valo, " gramos equivalen a ", resultado, " kilogramos."
	4:
		resultado <- valo * 1000
		Escribir valo, " kilogramos equivalen a ", resultado, " gramos."
		
De Otro Modo:
	Escribir "Opci�n inv�lida."
FinSeg�n

FinAlgoritmo
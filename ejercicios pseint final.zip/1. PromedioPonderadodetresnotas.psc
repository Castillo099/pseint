Algoritmo PromedioPonderadodetresnotas
    Definir nota1, nota2, nota3, promedio Como Real
    Definir peso1, peso2, peso3 Como Real
	
    peso1 <- 0.30
    peso2 <- 0.30
    peso3 <- 0.40
	
    Escribir "Ingresa la primera nota: "
    Leer nota1
    Escribir "Ingresa la segunda nota: "
    Leer nota2
    Escribir "Ingresa la tercera nota: "
    Leer nota3
	
    promedio <- (nota1 * peso1 + nota2 * peso2 + nota3 * peso3)
	
    Escribir "El promedio ponderado es: ", promedio
FinAlgoritmo

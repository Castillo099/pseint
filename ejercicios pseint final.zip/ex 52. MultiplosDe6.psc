Algoritmo MultiplosDe6
Definir num Como Entero
	escribir "bienvenidos a los multiplos de 6 de 1 al 1000"
    Para num <- 6 Hasta 1000 Con Paso 6 Hacer
        Escribir num
    FinPara
	
FinAlgoritmo
Proceso ContarDivisibles
	//pseudoc�digo que permita al usuario ingresar un n�mero y una lista de n�meros. 
	//El programa debe contar cu�ntos n�meros de la lista son divisibles entre el n�mero ingresado.
    Definir cantidadNumeros, lista, num, i, contador Como Entero
    
    Escribir "Ingrese un n�mero: "
    Leer num
	
    Escribir "Ingrese la cantidad de n�meros en la lista: "
    Leer cantidadNumeros

    Dimension lista[cantidadNumeros]

    Para i Desde 1 Hasta cantidadNumeros Hacer
        Escribir "Ingrese el n�mero ", i, ": "
        Leer lista[i]
    Fin Para
    contador <- 0
    Para i Desde 1 Hasta cantidadNumeros Hacer
        Si lista[i] % num = 0 Entonces
            contador <- contador + 1
        Fin Si
    Fin Para
    Escribir "La cantidad de n�meros divisibles entre ", num, " es: ", contador
Fin Proceso

Algoritmo GenerarNumerosAleatorios
    Definir i, num Como Entero
	Escribir "bienvenido al generador de numeros aleatorios"
    Escribir "por favor ingrese la cantidad de n�meros aleatorios que desea generar (N): "
    Leer Num
	
    Dimension numeros[Num]
	
    Para i Desde 1 Hasta Num Hacer
        numeros[i] <- Aleatorio(1, 100) 
    Fin Para
	
    Escribir "Los n�meros aleatorios generados son: "
    Para i Desde 1 Hasta Num Hacer
        Escribir numeros[i]
    Fin Para
FinAlgoritmo


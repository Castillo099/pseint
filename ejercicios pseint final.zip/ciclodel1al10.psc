Algoritmo ciclodel1al10
	definir i como entero
	escribir "bienvenido al ciclo de numeros entre 1 y 10"
	Para i<-1 Hasta 10 Con Paso 1 Hacer
		escribir i
	Fin Para
FinAlgoritmo

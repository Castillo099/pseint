Algoritmo RegistroAsistencia   
    Definir numEstudiantes, contadorPresentes, contadorAusentes Como Entero
    Definir respuesta Como Caracter
    Definir nombreArchivo Como cadena
	
	escribir "bienvenido a la asistencia de clase"
    Escribir "por favor ingrese el n�mero total de estudiantes: "
    Leer numEstudiantes
    Escribir "por favor ingrese el nombre del archivo para guardar los datos: "
    Leer nombreArchivo
	
 
    contadorPresentes <- 0
    contadorAusentes <- 0
	
   Para i <- 1 Hasta numEstudiantes Hacer
        Escribir "El estudiante ", i, ": �Asisti�? ingrese (N) para no y (S) para si "
        Leer respuesta
		
        Si respuesta = "S" Entonces
            Escribir nombreArchivo, "Estudiante ", i, ": Presente"
            contadorPresentes <- contadorPresentes + 1
        SiNo
            Escribir nombreArchivo, "Estudiante ", i, ": Ausente"
            contadorAusentes <- contadorAusentes + 1
        FinSi
    FinPara
	
    Escribir "N�mero de estudiantes presentes: ", contadorPresentes
    Escribir "N�mero de estudiantes ausentes: ", contadorAusentes
	
FinAlgoritmo
Algoritmo CelsiusAKelvin
    Definir celsius, kelvin Como Real
	escribir "bienvenidos a el convertidor de celcius a kelvin"
    Escribir "por favor ingrese la temperatura en grados Celsius: "
    Leer celsius
	
    kelvin <- celsius + 273.15
	
    Escribir "La temperatura en Kelvin es: ", kelvin " grados"
	
FinAlgoritmo
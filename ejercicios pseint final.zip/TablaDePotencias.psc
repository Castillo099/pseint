Algoritmo TablaDePotencias
    Definir num, potencia, resultado Como Entero
    Escribir "bienvenido a la consulta de la potenciade un numero"
    Escribir "por favor ingrese un n�mero para calcular sus potencias:"
    Leer num
    
    Escribir "Tabla de potencias de ", num
    
    Para potencia Desde 1 Hasta 5 Hacer
        resultado <- num ^ potencia
        Escribir num, " elevado a la ", potencia, " es igual a ", resultado
    FinPara
FinAlgoritmo

Algoritmo PromedioCalificaciones
    Definir nota, suma, contador Como Entero
    
    suma <- 0
    contador <- 0
	
	Escribir "bienvenido a el promedio de calificaciones"
    Mientras contador < 5 Hacer
        Escribir "por favor ingrese la calificaci�n del estudiante ", contador + 1, ": "
        Leer nota
		
        Mientras nota < 0 O nota > 10 Hacer
            Escribir "La calificaci�n debe estar entre 0 y 10. Ingrese nuevamente: "
            Leer nota
        FinMientras
		
        suma <- suma + nota
        contador <- contador + 1
    FinMientras

    Escribir "El promedio de las calificaciones es: ", suma / 5
	
FinAlgoritmo
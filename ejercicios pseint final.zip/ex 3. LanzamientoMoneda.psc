Algoritmo LanzamientoMoneda
    Definir resultado Como Entero
	Escribir "bievenidos a la simulacion de el lanzamiento de una moneda"
    resultado <- Aleatorio(1, 2)
	
    Si resultado = 1 Entonces
        Escribir "Sali� cara"
    SiNo
        Escribir "Sali� cruz"
    FinSi
	
FinAlgoritmo
Algoritmo celciusfharenheit
	definir celcius, fharenheit Como Real
	escribir "bienvenidos a la convercion de celcius, fharenheit"
	Escribir  "por favor Ingresa el valor de grados celsius:"
    Leer celcius
    grados_fahrenheit <- 1.8 * +32;
    Escribir "Valor de grados fahrenheit: ", grados_fahrenheit;
FinAlgoritmo

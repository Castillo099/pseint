Algoritmo ConversionMetrosAPies
	
    Definir metros, pies Como Real
	Escribir "binvenido a la conversion de metros apies"
    Escribir "Ingrese la medida en metros: "
    Leer metros

    pies <- metros * 3.28084
	
    Escribir metros, " metros equivalen a ", pies, " pies"
	
FinAlgoritmo
Algoritmo DescuentoCompra
    Definir precioOriginal, descuento, precioFinal Como Real
	escribir "bienvenido a el descuento de su compra"
    Escribir "por favor ingrese el valor de la compra: $"
    Leer precioOriginal
	
    Si precioOriginal > 200 Entonces
        descuento <- precioOriginal * 0.2
    SiNo
        Si precioOriginal > 100 Entonces
            descuento <- precioOriginal * 0.1
        SiNo
            descuento <- 0
        FinSi
    FinSi
	
    precioFinal <- precioOriginal - descuento
	

    Escribir "El descuento aplicado es de: $", descuento
    Escribir "El precio final a pagar es: $", precioFinal
	
FinAlgoritmo
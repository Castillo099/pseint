Algoritmo CalcularPotencia
    Definir base, exponente, resultado Como Entero
	escribir "bievenido  el calculo de potencia"
    Escribir "por favor ingrese la base: "
    Leer base
    Escribir "por favor ingrese el exponente: "
    Leer exponente
	
    resultado <- 1

    Para i <- 1 Hasta exponente Hacer
        resultado <- resultado * base
    FinPara
	
    Escribir "El resultado de ", base, " elevado a ", exponente, " es: ", resultado
FinAlgoritmo
Algoritmo VerificarVocal
    Definir carac Como Caracter
	
	Escribir "bienvenido a el verificador de vocales"
    Escribir "por favor ingrese un car�cter: "
    Leer carac
	
    carac <- Minusculas(carac)
	
    Si (carac = 'a') O (carac = 'e') O (carac = 'i') O (carac = 'o') O (carac = 'u') Entonces
        Escribir "El car�cter ", carac, " es una vocal."
    SiNo
        Escribir "El car�cter ", carac, " no es una vocal."
    FinSi
	
FinAlgoritmo
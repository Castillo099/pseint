Proceso PagoConTarjeta
    Definir numeroTarjeta, fechaExpiracion, cvv Como Caracter
    Definir monto, saldoDisponible Como Real
    Definir aprobado Como Logico
	
    saldoDisponible <- 500000.0 
	
    Escribir "Bienvenido al sistema de pago con tarjeta de cr�dito"
    
    Escribir "por favor ingrese el n�mero de la tarjeta de cr�dito:"
    Leer numeroTarjeta
    Escribir "porfavor ingrese la fecha de expiraci�n (MM/AAAA):"
    Leer fechaExpiracion
    Escribir "por favor ingrese el c�digo CVV:"
    Leer cvv
    Escribir "por favor ingrese el monto a pagar:"
    Leer monto
	
    Si monto > saldoDisponible Entonces
        Escribir "Pago rechazado. Saldo insuficiente en la tarjeta."
        aprobado <- Falso
    Sino
        aprobado <- Verdadero
    FinSi
	
    Si aprobado Entonces
        saldoDisponible <- saldoDisponible - monto
        Escribir "el pago fue aprobado. El monto del pago fue de: $", monto
        Escribir "Su nuevo saldo disponible es: $", saldoDisponible
    Sino
        Escribir "El pago no ha sido realizado."
    FinSi
	
    Escribir "Gracias por usar nuestro sistema de pago."
Fin Proceso


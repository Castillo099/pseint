Algoritmo usuarioycontrase�a
	Definir usuario, contrase�a Como Caracter
	
	Escribir "Dame un usuario"
	leer usuario
	Escribir "Dame la contrase�a"
	leer contrase�a
	
	si usuario == "felipe" y contrase�a = "felipe0909" Entonces
		Escribir "Los datos son correctos"
	SiNo
		Escribir "Los datos son incorrectos"
	FinSi
FinAlgoritmo

Proceso NumerosPares
    Definir limite, i Como Entero
	escribir "bienvenido a el promedio de numeros pares "
    Escribir "Ingrese un n�mero l�mite: "
    Leer limite
    Escribir "Los n�meros pares desde 1 hasta ", limite, " son:"
    Para i = 1 Hasta limite Con Paso 1 Hacer
        Si i % 2 = 0 Entonces
            Escribir i
        FinSi
    FinPara
FinProceso

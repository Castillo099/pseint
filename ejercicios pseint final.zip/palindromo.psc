Algoritmo palindromo
	definir palabra Como Caracter
	escribir "bienvenido a la consulta de un palindromo"
	escribir "ingrese una palabra"
	leer palabra
	inversa=""
	long=longitud(palabra)
	Para i<-long Hasta 1 Con Paso -1 Hacer
		inversa<-inversa+Subcadena(palabra,i,i)
	Fin Para
	Escribir inversa
	Si palabra=inversa Entonces
		escribir"la palabra es palindromo"
	SiNo
		Escribir "la palabra no palindromo"
	Fin Si
FinAlgoritmo

Algoritmo RaizCuadrada
    Definir numero, estimacion, precision Como Real
	
	Escribir "bienvenidos a la raiz cuadrada de un numero"
    Escribir "Ingrese un n�mero positivo: "
    Leer numero
	
    estimacion <- numero / 2

    precision <- 0.00001

    Mientras Abs(estimacion*estimacion - numero) > precision Hacer
        estimacion <- (estimacion + numero/estimacion) / 2
    FinMientras
	
    Escribir "La ra�z cuadrada aproximada de ", numero, " es: ", estimacion
	
FinAlgoritmo
Algoritmo EdadParaVotar
	
    Definir edad Como Entero
	Escribir "bienvenido a la consulta de su votacion"
    Escribir "por favor ingrese su edad: "
    Leer edad
	
    Si edad >= 18 Entonces
        Escribir "Usted tiene edad suficiente para votar."
    SiNo
        Escribir "Usted a�n no tiene edad suficiente para votar."
    FinSi
	
FinAlgoritmo
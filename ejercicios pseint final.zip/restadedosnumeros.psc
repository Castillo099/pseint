Algoritmo restadedosnumeros
	definir num1, num2, resultadoresta Como entero 
	// elaborado por ANDRES FELIPE TRUJILLO
        // 1 SEMESTRE JORNADA NOCTURNA
	escribir "bienvenidos a la resta de dos numeros"
	escribir "por favor ingrese el primer numero"
	leer num1 
	escribir "ingrese el segundo numero"
	leer num2 
	// Aqui se realiza la operacion de la resta
	resultadoresta <- num1 - num2
	Escribir "el resultado de la resta de dos numeros es:", resultadoresta
FinAlgoritmo

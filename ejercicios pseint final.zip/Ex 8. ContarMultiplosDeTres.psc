Algoritmo ContarMultiplosDeTres

    Definir inicio, fi, contador Como Entero
	escribir "bienvenido al promedio de multipliplos de 3 entre dos numeros"
    Escribir "Ingrese el inicio del rango: "
    Leer inicio
    Escribir "Ingrese el fin del rango: "
    Leer fi

    contador <- 0

    Para i <- inicio Hasta fi Hacer
        Si i mod 3 = 0 Entonces
            contador <- contador + 1
        FinSi
    FinPara

    Escribir "Hay ", contador, " n�meros m�ltiplos de 3 entre ", inicio, " y ", fi
	
FinAlgoritmo
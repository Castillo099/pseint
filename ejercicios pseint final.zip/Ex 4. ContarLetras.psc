
Algoritmo ContarLetras
    Definir frase Como Caracter
    Definir contador, i Como Entero
    escribir "bienvenidos a el contador de letras de una frase"
    Escribir "por favor ingrese una frase: "
    Leer frase
    
    contador <- 0
    
    Para i <- 1 Hasta Longitud(frase) Hacer
        contador <- contador + 1
    FinPara
    
    Escribir "La frase tiene ", contador, " letras."
FinAlgoritmo
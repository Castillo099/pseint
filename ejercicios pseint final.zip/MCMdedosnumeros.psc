Algoritmo MCMdedosnumeros
	Definir a, b, mcm, mayor Como Entero
	Escribir "bienvienido a la consulta de MCM de 2 numeros"
    Escribir "por favor Ingrese el primer n�mero:"
    Leer a
    Escribir "por favor Ingrese el segundo n�mero:"
    Leer b
	
    Si a > b Entonces
        mayor = a
    Sino
        mayor = b
    Fin Si

    mcm = mayor
    Mientras (mcm Mod a <> 0) O (mcm Mod b <> 0) Hacer
        mcm = mcm + mayor
    Fin Mientras

    Escribir "El M�nimo Com�n M�ltiplo es:", mcm
FinAlgoritmo
